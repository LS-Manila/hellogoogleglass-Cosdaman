/*
 *
 */
package com.indooratlas.android.sdk.indoornavigation.sharelocation.channel;

/**
 *
 */
public class LocationChannelException extends Exception {

    public LocationChannelException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
